# WebScrap
Using Webscraping scrapped 300 pages of the information regarding Zomato South-Banglore resturants.
Using Python,Js,beautifulsoup4.
